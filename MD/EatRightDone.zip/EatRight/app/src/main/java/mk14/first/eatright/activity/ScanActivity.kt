package mk14.first.eatright.activity

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import mk14.first.eatright.R
import mk14.first.eatright.retrofit.RetrofitClient
import mk14.first.eatright.api.ApiResponse
import mk14.first.eatright.api.Barcode
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class ScanActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var btnScan: Button
    private lateinit var tvProductName: TextView
    private lateinit var tvBrand: TextView
    private lateinit var tvNutritionalInfo: TextView
    private var imageCapture: ImageCapture? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)

        previewView = findViewById(R.id.previewView)
        btnScan = findViewById(R.id.btnScan)
        tvProductName = findViewById(R.id.tvProductName)
        tvBrand = findViewById(R.id.tvBrand)
        tvNutritionalInfo = findViewById(R.id.tvNutritionalInfo)

        startCamera()

        btnScan.setOnClickListener {
            captureImageAndSendToApi()
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            imageCapture = ImageCapture.Builder().build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    preview,
                    imageCapture
                )
            } catch (exc: Exception) {
                Log.e("ScanActivity", "Camera binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureImageAndSendToApi() {
        val imageCapture = imageCapture ?: return

        val file = File(externalMediaDirs.firstOrNull(), "${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()

        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    Log.d("ScanActivity", "Image saved at: ${file.absolutePath}")
                    uploadImageToApi(file)
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("ScanActivity", "Image capture failed", exception)
                }
            })
    }

    private fun uploadImageToApi(file: File) {
        val requestBody = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
        val multipartBody = MultipartBody.Part.createFormData("file", file.name, requestBody)

        val apiService = RetrofitClient.apiService
        apiService.uploadImage(multipartBody).enqueue(object : Callback<ApiResponse> {
            override fun onResponse(
                call: Call<ApiResponse>,
                response: Response<ApiResponse>
            ) {
                if (response.isSuccessful) {
                    val barcode = response.body()?.barcodes?.firstOrNull()
                    if (barcode != null) {
                        displayProductDetails(barcode)
                    } else {
                        showToast("No barcode found!")
                    }
                } else {
                    Log.e("ScanActivity", "API error: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                Log.e("ScanActivity", "API call failed", t)
                showToast("Failed to connect to API")
            }
        })
    }

    private fun displayProductDetails(barcode: Barcode) {
        tvProductName.text = "Product Name: ${barcode.product_name}"
        tvBrand.text = "Brand: ${barcode.brand}"
        tvNutritionalInfo.text = """
            Nutritional Info:
            Calories: ${barcode.nutritional_info.calories}
            Fat: ${barcode.nutritional_info.fat}g
            Carbs: ${barcode.nutritional_info.carbohydrates}g
            Protein: ${barcode.nutritional_info.protein}g
            Sugar: ${barcode.nutritional_info.sugar}g
        """.trimIndent()

        tvProductName.visibility = View.VISIBLE
        tvBrand.visibility = View.VISIBLE
        tvNutritionalInfo.visibility = View.VISIBLE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
